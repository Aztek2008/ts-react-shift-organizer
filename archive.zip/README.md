# ts-react-shift-organizer
Shifts management build with typescript and react

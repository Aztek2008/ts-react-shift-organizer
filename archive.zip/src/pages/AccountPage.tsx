import UserInfo from 'features/userInfo/UserInfo';
import React from 'react';

const AccountPage = () => {
  return (
    <div>
      <UserInfo />
    </div>
  );
};

export default AccountPage;

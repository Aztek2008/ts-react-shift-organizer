import ShiftsList from 'features/shiftsList/ShiftsList';

const MainPage = () => {
  return (
    <div>
      <ShiftsList />
    </div>
  );
};

export default MainPage;
